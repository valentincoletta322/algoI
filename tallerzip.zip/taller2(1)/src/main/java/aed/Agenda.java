package aed;

public class Agenda {

    public Agenda(Fecha fechaActual) {
        // Implementar
    }

    public void agregarRecordatorio(Recordatorio recordatorio) {
        // Implementar
    }

    @Override
    public String toString() {
        // Implementar
        return "";
    }

    public void incrementarDia() {
        // Implementar
    }

    public Fecha fechaActual() {
        // Implementar
        return null;
    }

}
