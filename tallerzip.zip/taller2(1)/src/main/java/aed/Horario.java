package aed;

public class Horario {
    private int hora;
    private int minutos;

    public Horario(int hora, int minutos) {
        this.hora = hora;
        this.minutos = minutos;
    }

    public int hora() {
        return this.hora;
    }

    public int minutos() {
        return this.minutos;
    }

    @Override
    public String toString() {
        String horario_to_string = "";
        horario_to_string += Integer.toString(this.hora);
        horario_to_string += ":";
        horario_to_string += Integer.toString(this.minutos);
        return horario_to_string;
    }

    @Override
    public boolean equals(Object otro) {
        if (otro == null || otro.getClass() != this.getClass()){
            return false;
        }
        
        else {
            Horario nuevoHorario = (Horario) otro;
            return (nuevoHorario.hora() == this.hora && nuevoHorario.minutos() == this.minutos);
        }
    }

}
